﻿import requests
from time import sleep

f = open("./cron.txt", "r")
crons = f.read().split("\n")

loop = True
phien = 1
limit = 3

while loop:
	for cron in crons:
		res = requests.get(cron)

		print('+ URL: ' + cron)
		print('+ Response: ' + res.text)
		print('-----------------------------------')
		

	sleep(limit)